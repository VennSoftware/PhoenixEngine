#pragma once
#include <Phoenix/Core.hpp>
#define PHNX_MAX_VERTICES (65536)
namespace phnx {
	namespace gfx {



		class RenderPipeline {
		public:
		};
	}
}